f_s = 10000;
t_step = 1/(f_s);
%1 sec
total_t = 1;
t_range = 0:(t_step):((total_t)-(t_step));
sample = (f_s)*(total_t);
%DTMF for tone 1
upper_band1 = 1209;
lower_band1 = 697;
%DTMF for tone 2
upper_band2 = 1336;
lower_band2 = 687;
%DTMF for tone 4
upper_band4 = 1209;
lower_band4 = 770;

%the tones are the sumamtion of the upper and lower band sinusoidal
%frequencies
tone_1 = sin(2*pi*(lower_band1)*(t_range)) + sin(2*pi*(upper_band1)*(t_range));
tone_2 = sin(2*pi*(lower_band2)*(t_range)) + sin(2*pi*(upper_band2)*(t_range));
tone_4 = sin(2*pi*(lower_band4)*(t_range)) + sin(2*pi*(upper_band4)*(t_range));

%outputting sound files
audiowrite('tone1.wav', tone_1, f_s);
audiowrite('tone2.wav', tone_2, f_s);
audiowrite('tone4.wav', tone_4, f_s);