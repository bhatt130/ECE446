%[data, fs] = audioread('YourFile.wav');
%data_fft = fft(data);
%plot(abs(data_fft(:,1)))
%https://www.mathworks.com/matlabcentral/answers/421460-how-do-i-get-the-fft-from-the-audio-wav-file

%uploading audio file data
[data_empty,fs1] = audioread('empty_bottle.wav');
[data_filled,fs2] = audioread('filled_bottle.wav');

%number of samples
sample1 = length(data_empty);

%number of samples
sample2 = length(data_filled);

%taking fft for both the bottles
fourier1 = fft(data_empty);
fourier2 = fft(data_filled);

%plotting the data
frequency1 = (fs1)*(0:(sample1/2-1))/sample1;
frequency2 = (fs2)*(0:(sample2/2-1))/sample2;
figure;
plot(frequency1, fourier1(1:sample1/2));
title('Amplitude of Empty Bottle in Frequency domain');
xlabel('Frequency in Hz');
ylabel('Amplitude');

figure;
plot(frequency2, fourier2(1:sample2/2));
title('Amplitude of Filled Bottle in Frequency domain');
xlabel('Frequency in Hz');
ylabel('Amplitude');