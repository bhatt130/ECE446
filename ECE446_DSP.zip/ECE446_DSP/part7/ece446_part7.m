%importing using audioread
[voice, fs1] = audioread('Violin_humanvoice.wav');
[violin, fs2] = audioread('a440.wav');

fft_voice = abs(fft(voice));
fft_violin = abs(fft(violin));

sample1 = length(voice);
sample2 = length(violin);

frequency_voice = fs1*(0:(sample1/2-1))/sample1;
frequency_violin = fs1*(0:(sample2/2-1))/sample2;

%plots
figure;
plot((frequency_voice), fft_voice(1:sample1/2));
title('Voice in frequency domain');
xlabel('Frequency in Hz');
ylabel('Aomplitude');

figure;
plot((frequency_violin), fft_voice(1:sample2/2));
title('Violin in frequency domain');
xlabel('Frequency in Hz');
ylabel('Amplitude');