%reference: https://www.mathworks.com/help/signal/ref/spectrogram.html
%https://www.mathworks.com/help/signal/ref/spectrogram.html#d126e200344

%s = spectrogram(x,window,noverlap,nfft)

%part 8
hchirp = dsp.Chirp( ...
    'InitialFrequency', 500,...
    'TargetFrequency', 7500, ...
    'TargetTime', 0.1, ...
    'SweepTime', 1, ...
    'SampleRate', 8000, ...
    'SamplesPerFrame', 750);

chirpData = (step(hchirp))';

sample = 256;
%why Hann window used: https://www.mathworks.com/help/signal/ref/spectrogram.html#bultmx7-window
window = hann(256);
%spectrogram vector
%253 is the 99% overlapping value of 256
[s, f, t, n] = spectrogram(chirpData, window, 253, sample);

%plotting using imagesc
%openExample('signal/ReassignedSpectrogramOfQuadraticChirpExample')
figure;
imagesc(t, f, 10*log10(n));
axis xy;
xlabel('Time');
ylabel('Frequency');
title('Spectrogram of chirpData');
colorbar;
