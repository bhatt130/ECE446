%we want to take fft and then find peaks
%reference: https://www.mathworks.com/help/signal/ref/findpeaks.html#
%different peaks correspond to different frequency values of the tones

%arbitraryinput signal has been taken for algorithm demo
%the input signal in reality is one of the tones, tone 1/2/4...
samples = length(input_signal);
f_s = 10000; %part 3
frequencies = (0:samples)*((f_s))/samples;

fft_inputsignal = abs(fft(input_signal));
%the tones are the sumamtion of the upper and lower band sinusoidal
%frequencies
tone_1 = sin(2*pi*(lower_band1)*(t_range)) + sin(2*pi*(upper_band1)*(t_range));
tone_2 = sin(2*pi*(lower_band2)*(t_range)) + sin(2*pi*(upper_band2)*(t_range));
tone_4 = sin(2*pi*(lower_band4)*(t_range)) + sin(2*pi*(upper_band4)*(t_range));

figure;
plot(frequencies, fft_inputsignal);
xlabel('Frequency ');
ylabel('Magnitude');
title('FFT of Input Signal');

[pks, locs] = find_peak(fft_input_signal);
disp(frequencies(locs));

%vector for storing tones detected
vector_tones = {};

%if condition of tone 1 to find cut-off, neglecting tone 2 and 4
%else if conditions can be used under the block of code below to check
%against other tones
if (frequencies(locs) <= upper_threshold_tone1
    vector_tones{} = 'Tone 1';
else vector_tones{} = 'Not a valid tone';
end

%return
vector_tone;
    
    