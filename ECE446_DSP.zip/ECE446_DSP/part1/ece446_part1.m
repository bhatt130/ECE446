f_s = 44100;
t = 3;
f1 = 440;
f2 = 660;
mag = 0.5;
total_sample = (f_s)*t;

time = (0 : (total_sample - 1))/f_s;

%time-domain represemtation of signal ensures real signal
signal_time = mag*(cos(2*pi*f1*t) + cos(2*pi*f2*t));

%frequency-domain represenattion of the signal
%using FFT
signal_frequency = fft(signal_time);

%WAV file
audiowrite('part1.wav', signal_frequency, f_s);

