f_s = 44100;
f_sine = 1000;
t_step = 1/(f_s);
sample = 10*(f_s);
%time vector ending right before 10 seconds
t_range = 0:(t_step):(10-(t_step));

%sine wave using this range vector of time
x1 = sin(2*pi*(f_sine)*(t_range));
%same as x1
x2 = x1;
%values of 1-9 seconds will be set to 0 for x2
x2(t_range >=1 & t_range<9) = 0;

%we will plot the absolute FFT of x1 and x2 to discuss in the report
%taking fft of both x1 and x2
x1_fft = fft(x1, sample);
x2_fft = fft(x2, sample);

%plot 1 of x1
figure;
%taken for symmetry of DDT for real signals
nyquist_frequency = (sample/2+1);
f = linspace(0, f_s/2, nyquist_frequency);
plot(f, abs(x1_fft(1:nyquist_frequency)));
title('Plot of FFT of x1 signal');
xlabel('Frequency (Hz)');
ylabel('Magnitude of x1(f)');
%fundamental freq is 1k, but 1.5k was chosen to observe nearby frequencies
xlim([0 1500]);

%plot 2 of x2
figure;
%taken for symmetry of DDT for real signals
nyquist_frequency = (sample/2+1);
f = linspace(0, f_s/2, nyquist_frequency);
plot(f, abs(x2_fft(1:nyquist_frequency)));
title('Plot of FFT of x2 signal');
xlabel('Frequency (Hz)');
ylabel('Magnitude of x1(f)');
%fundamental freq is 1k, but 1.5k was chosen to observe nearby frequencies
xlim([0 1500]);