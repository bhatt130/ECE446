%cont dial tone is low 350 and high 440
fs = 10000;
%for 5 seconds time vector
time = 0:(1/fs):5;
f_low = 350;
f_high = 440;
dial_signal = sin(2*pi*(f_low)*t) + sin(2*pi*(f_high)*t);
%audiowrite('dialtonecont.wav', dial_signal, fs);

%for busy signal, low is 480 and high is 620 and it is on and off for 0.5
%seconds
fs = 10000;
%for 5 seconds time vector
time = 0:(1/fs):(0.5-1)/fs;
f_low = 480;
f_high = 620;
busy_signal = sin(2*pi*(f_low)*t) + sin(2*pi*(f_high)*t);
%audiowrite('busytone.wav', busy_signal, fs);