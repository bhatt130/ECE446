%reference: https://www.mathworks.com/help/thingspeak/remove-dc-component-and-display-results.html
%the target time and samplesperframe were adjusted depending on the plot
%display and abve ref
hchirp = dsp.Chirp( ...
    'InitialFrequency', 500,...
    'TargetFrequency', 7500, ...
    'TargetTime', 0.1, ...
    'SweepTime', 1, ...
    'SampleRate', 8000, ...
    'SamplesPerFrame', 750);

chirpData = (step(hchirp))';
evenFlag = mod(minute(datetime('now')),2);
if evenFlag
    chirpData = fliplr(chirpData);
end

figure;
plot(chirpData);
title('Chirp Signal for sample frequency of 8kHz in Time domain');
xlabel('Time');
ylabel('Amplitude');

%the following were used to listen to the sounds
%sound(chirpData, 16000);
%sound(chirpData, 8000);

%audio output for assessing
audiowrite('chirp_sixteenk.wav', chirpData, 16000);
audiowrite('chirp_eightk.wav', chirpData, 8000);