%doppler effect
%spectrogram(x,256*20,256*15,256*20,Fs,’yaxis')
[data, fs] = audioread('doppler.wav');
spectrogram(data, 256*20, 256*15, 256*20, fs, 'yaxis');
title('Spectrogram of Flight Taking Off');